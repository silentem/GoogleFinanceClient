package candleChart;

import TeacherUtil.ParserFromString;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.Pane;

import java.util.ArrayList;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Влад on 31.01.2017.
 */
public class MyChart extends Pane {

    public CandleStickChart chart;
    public LinkedList<double[] > toBuild = new LinkedList<double[]>();
    public ArrayList<String > params = new ArrayList<String>();
    public XYChart.Series<Number, Number> series = new XYChart.Series<Number, Number>();
    public ObservableList<XYChart.Series<Number, Number>> data ;

    public MyChart(){
        final NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Time frame");
        xAxis.setMinorTickCount(0);
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Price");
        yAxis.setForceZeroInRange(false);

        chart = new CandleStickChart(xAxis, yAxis);
        chart.setPrefHeight(600);
        chart.setPrefWidth(700);
        getChildren().add(chart);


        //makeRequest("https://www.google.com/finance/getprices?q=BIDU&i=3600");

        //setSeries();

        //setData();

    }
    public void makeRequest(String url){
      /*  params.clear();
        BufferedReader reader = null;
        try{
            URL request = new URL(url);

            reader = new BufferedReader(new InputStreamReader(request.openStream()));

            //пропустить заголовки

            int i = 0;

            while( i++ < 8)
                reader.readLine();

            String resultString;
            while ( (resultString = reader.readLine()) != null){
                params.add(resultString);
                System.out.println(resultString);
            }

        }catch(Exception ex){
            System.err.println("!!!!");
        }*/
    }

    public void setSeries(){
        series.getData().clear();
        toBuild.clear();
        int j = params.size()-20;
        if(j < 0) j=0;

        //копіювання даних
        try {
            for (; j < params.size(); j++) {
                toBuild.add(ParserFromString.parseString(params.get(j)));
            }

            double firstPosition = toBuild.get(0)[0];

            for(double[] param:toBuild){
                param[0] = param[0] - firstPosition + 1;
            }

            for (int i = 0; i < toBuild.size(); i++) {
                double[] param = toBuild.get(i);
                series.getData().add(new XYChart.Data<Number, Number>(param[0], param[4], new CandleStickExtraValues(param[1], param[2], param[3], 1.0)));
            }
            System.out.println(series.getData().size());
        }catch (Exception ex){
            System.err.println(ex.getMessage());
        }
    }
    public void setData(){
        data = FXCollections.observableArrayList(series);
        chart.setData(data);
    }

    public void setSeries(List<double[] > params){
        series.getData().clear();
        //копіювання даних
        try {
            for (int i = 0; i < params.size(); i++) {
                double[] param = params.get(i);
                series.getData().add(new XYChart.Data<Number, Number>(param[0], param[4], new CandleStickExtraValues(param[1], param[2], param[3], 1.0)));
            }
            System.out.println(series.getData().size());
        }catch (Exception ex){
            System.err.println(ex.getMessage());
        }
    }

}
